export default Object.entries;
