export default n=>(n%2)===1;
