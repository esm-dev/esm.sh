export default Number.isNaN;
