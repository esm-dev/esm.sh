export default (a,p,t)=>a.find(p,t);
