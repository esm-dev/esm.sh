export default (obj,prop)=>Object.prototype.hasOwnProperty.call(obj,prop);
