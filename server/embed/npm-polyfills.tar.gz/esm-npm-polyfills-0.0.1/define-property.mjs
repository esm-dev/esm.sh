export default Object.defineProperty;
