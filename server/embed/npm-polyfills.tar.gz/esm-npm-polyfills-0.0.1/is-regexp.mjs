export default v=>v instanceof RegExp;
