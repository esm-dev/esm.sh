export default Function.prototype.bind;
