export default (a,p,t)=>a.filter(p,t);
