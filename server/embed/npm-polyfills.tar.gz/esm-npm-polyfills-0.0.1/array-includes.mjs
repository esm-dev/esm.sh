export default (a,p,i)=>a.includes(p,i);
