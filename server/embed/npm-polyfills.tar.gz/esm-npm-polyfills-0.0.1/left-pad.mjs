export default (s,l,c)=>s.padStart(l,c);
