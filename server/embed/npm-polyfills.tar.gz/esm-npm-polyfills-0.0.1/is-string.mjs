export default v=>typeof v==="string";
