export default ()=>typeof Symbol.toStringTag==="symbol";
