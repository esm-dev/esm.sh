export const every=(a,p,t)=>a.every(p,t);
export default every;
