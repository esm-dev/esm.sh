export default Object.assign;
