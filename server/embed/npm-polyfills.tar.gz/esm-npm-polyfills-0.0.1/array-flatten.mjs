export const flatten=(a,d)=>a.flat(typeof d<"u"?d:Infinity);
export default flatten;
