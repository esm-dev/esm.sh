export default Object.is;
