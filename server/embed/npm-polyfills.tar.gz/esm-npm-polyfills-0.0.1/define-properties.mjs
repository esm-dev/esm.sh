export default Object.defineProperties;
