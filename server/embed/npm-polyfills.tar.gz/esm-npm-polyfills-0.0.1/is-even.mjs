export default n=>(n%2)===0;
