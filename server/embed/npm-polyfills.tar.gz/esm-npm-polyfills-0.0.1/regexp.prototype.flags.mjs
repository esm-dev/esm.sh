export default r=>r.flags;
