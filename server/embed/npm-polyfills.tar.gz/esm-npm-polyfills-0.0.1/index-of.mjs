export default (a,el,i)=>a.indexOf(el,i);
