export default v=>typeof v==="number";
