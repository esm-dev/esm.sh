import { a as dew$1, c as dew$2, e as dew$3, f as dew$4, g as dew$5, h as dew$6, i as dew$7 } from './chunk-44e51b61.js';

var exports = {},
    _dewExec = false;
function dew() {
  if (_dewExec) return exports;
  _dewExec = true;
  exports = exports = dew$1();
  exports.Stream = exports;
  exports.Readable = exports;
  exports.Writable = dew$2();
  exports.Duplex = dew$3();
  exports.Transform = dew$4();
  exports.PassThrough = dew$5();
  exports.finished = dew$6();
  exports.pipeline = dew$7();
  return exports;
}

export { dew as d };
