import { a as e$1 } from './chunk-4ccc3a29.js';
export { a as default } from './chunk-4ccc3a29.js';

var StringDecoder = e$1.StringDecoder;

export { StringDecoder };
