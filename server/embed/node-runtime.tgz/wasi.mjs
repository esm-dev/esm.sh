function e(r){return class{__unenv__=!0;constructor(){throw new Error(`[unenv] ${r} is not implemented yet!`)}}}var t=e("wasi.WASI"),a={WASI:t};export{t as WASI,a as default};
