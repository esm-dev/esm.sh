import{a as o,b as r,c as s,d as t,e as d,f as c,g as i}from"./chunk-DKR7TGZO.mjs";export{o as decode,i as default,r as encode,t as toASCII,s as toUnicode,c as ucs2,d as version};
